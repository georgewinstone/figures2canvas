# figures2canvas
Merges all open python matplotlib figures, alpha build 
